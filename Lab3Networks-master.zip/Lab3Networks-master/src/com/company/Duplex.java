package com.company;/*
 * TextDuplex.java
 */

import java.util.Scanner;

/**
 *
 * @author  abj
 */
 class TextDuplex {

    public static void main (String[] args){
        Scanner reader = new Scanner(System.in);
        System.out.println("Enter Datagram Socket Number (1-4): ");
        int socketNum = reader.nextInt();
        TextReceiverThread receiver = new TextReceiverThread(socketNum);
        TextSenderThread sender = new TextSenderThread(socketNum);

        receiver.start();
        sender.start();

    }

}